License

Call to Arms (Lu Xun), collection of short stories.

LuXun_black : Thousand pointing fingers, willing ox bow (Zhao Yannian's Woodcut 1961)

LuXun_color : Thousand pointing fingers, willing ox bow (Yin Shoushi's Chinese Ink 1973)(after image processing)


According to the copyright law of People's Republic of China, the use of the above three works of art in scientific research and study is allowed.Because it is out of copyright in the copyright law of the Republic of People's Republic of China, so Chinese law is no longer on the "Call to Arms" for copyright protection.But if you want to use two pieces of art in business, because the time limit for copyright is not over, you have to get the consent of the artist.

---------------------stopwords---------------------
stopwords: Free to use, without authorization 

Shandong University of Science and Technology (Ji'nan campus) Software Alliance Laboratory(2017) Font Tian 
