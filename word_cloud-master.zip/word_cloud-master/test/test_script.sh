#!/bin/bash

# Test whether the installed script (executable) works.

echo "Test the command line utility..."
wordcloud_cli.py --help
